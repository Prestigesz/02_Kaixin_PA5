﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;
    //public int Coins=0;
    public Text score;
    public static float Score;
    public static int Once = 1;
    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = this.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
        if (Score == 4 && Once == 1)
        {
            Once = 2;
            SceneManager.LoadScene(3);
        }
        if (Score == 8 && Once == 2)
        {
            SceneManager.LoadScene(1);
            Score = 0;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "Obstacles")
        {
            SceneManager.LoadScene(2);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Coin")
        {
            Score++;
            score.text = "Score :  " + Score;
            Destroy(other.gameObject);


        }
    }

    /* private void OnGUI()
     {
         GUI.Label(new Rect(10, 10, 100, 20), "Score : " + points);
     }*/
}
